本数据集为疾病相似语句匹配分析数据集，包含：
	training.csv	15840条
	validation.csv	1980条
	test.csv		1981条
	submit.csv

	submit.csv为提交测试结果的格式：
		每一行为一个id和预测的两个提问的相关性，二者以","隔开
		id要与本文件夹中test.csvsv中id的顺序保持一致
	